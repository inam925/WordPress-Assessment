	<footer>
		<div class="min-ec-footer-field">
			<p class="min-ec-label">&copy;2023</p>
			<p class="min-ec-value"><?php echo esc_html__('Made by Inam Ul Haq', 'min_ec_textdomain') ?></p>
		</div>
	</footer>
	<?php wp_footer(); ?>
	</body>

	</html>